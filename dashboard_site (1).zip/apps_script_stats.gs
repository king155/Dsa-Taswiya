/* Google Apps Script: يستقبل إحصائيات البرنامج ويحفظها في Google Drive، ويعيدها للوحة.
   خطوات الإعداد:
   1) افتح script.new (أو من Google Drive: جديد > المزيد > Google Apps Script) والصق هذا الكود.
   2) من Project Settings (الترس) > Script Properties أضف خاصية:
        Property: TOKEN     Value: (رمز سري طويل تختاره، وضعه نفسه في إعدادات البرنامج)
   3) Deploy > New deployment > Web app
        Execute as: Me
        Who has access: Anyone
   4) انسخ رابط الـ Web app (ينتهي بـ /exec) وضعه في إعدادات البرنامج وفي STATS_URL داخل dashboard.html.
*/
var FILE_NAME = 'filaha-stats.json';

function doPost(e){
  try{
    var d = JSON.parse(e.postData.contents);
    var expected = PropertiesService.getScriptProperties().getProperty('TOKEN');
    if(!expected || d.token !== expected) return jsonOut({ok:false, error:'unauthorized'});
    var json = JSON.stringify(d.payload || {});
    var files = DriveApp.getFilesByName(FILE_NAME);
    if(files.hasNext()){ files.next().setContent(json); }
    else { DriveApp.createFile(FILE_NAME, json, 'application/json'); }
    return jsonOut({ok:true});
  }catch(err){
    return jsonOut({ok:false, error:String(err)});
  }
}

function doGet(e){
  var files = DriveApp.getFilesByName(FILE_NAME);
  if(!files.hasNext()) return jsonOut({ok:false, error:'لا توجد بيانات بعد'});
  return ContentService.createTextOutput(files.next().getBlob().getDataAsString())
    .setMimeType(ContentService.MimeType.JSON);
}

function jsonOut(o){
  return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON);
}
